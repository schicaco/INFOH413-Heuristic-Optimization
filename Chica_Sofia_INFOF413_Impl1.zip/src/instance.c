#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#include "instance.h"
#include "utilities.h"

#define BUFSIZE 1024

long int PSize;

/* Read a file instance, returning the data matrix. 
   At the moment works with LOLIB instances */
long int **readInstance(const char *filename) {
    FILE *f;
    char buffer[BUFSIZE+1];
    long int l, i, j, t;
    char *k;
    long int **r;
   
    buffer[BUFSIZE] = '\0';

    f = fopen(filename, "r");
    if ( !f ) {
	perror("readInstance");
	fatal("readInstance: Error on reading instance.");
    }
    
    if (fgets(buffer, BUFSIZE, f) == NULL)
        fatal("readInstance: EOF reading header.");
    l = strlen(buffer);

    if ( !l ) 
	fatal("readInstance: File instance is empty.");

    if (buffer[l-1] != '\n')
	fatal("readInstance: Header too long.");
    
    /* We can save the header with a strncpy if needed */
    
    /* Next line is the problem size: /^\s*(\d+)\s*$/ */

    if (fgets(buffer, BUFSIZE, f) == NULL)
        fatal("readInstance: EOF reading size.");
    l = strlen(buffer);

    if (buffer[l-1] != '\n')
	fatal("readInstance: Unexpected long data where size was expected");
    
    for (i = 0; (i < (l-1)) && ( (buffer[i] < '0') || (buffer[i] > '9') ); 
	 i++);
    
    if (i == (l-1)) {
	printf("%ld (%ld) [%s]", i, l-1, buffer);
	fatal("readInstance: Size expected but not found.");
    }
    PSize = atoi( &buffer[i] );

    r = createMatrix(PSize);

    i = 0; j = 0; 

    while ( i < PSize ) {
        if (fgets(buffer, BUFSIZE, f) == NULL) {
            fatal("readInstance: Not enough elements.");
        }
        l = strlen( buffer );
        if (buffer[l-1] != '\n') {
            sprintf(buffer, 
                "readInstance: Line %ld malformed "
                "(too long or unexpected EOF)", 
                i+2);
            fatal( buffer );
        }
        for (t = FALSE, k = buffer; *k != '\n'; k++) 
            if ( ( ( *k >= '0' ) && (*k <= '9') ) || ( *k == '-' ) ) {
            if ( !t ) {
                t = TRUE;
                r[i][j] = atoi( k ); 
                if ( (++j) == PSize ) {
                j = 0; 
                if ( (++i) == PSize ) break;
                }
            }
            } else 
            t = FALSE;
    }

    /* There is no control too see if there are too many elements in respect
       of the specified size */

    // Control if there are too many elements in respect of the specified size 
    // TODO: to check  
    if (fgets(buffer, BUFSIZE, f) != NULL) {
        l = strlen( buffer );
        if (buffer[l-1] != '\n') {
            sprintf(buffer, 
                "readInstance: Line %ld malformed "
                "(too long or unexpected EOF)", 
                i+2);
            fatal( buffer );
        }
        for (k = buffer; *k != '\n'; k++) 
            if ( ( ( *k >= '0' ) && (*k <= '9') ) || ( *k == '-' ) ) {
            sprintf(buffer, 
                "readInstance: Too many elements in the instance "
                "(expected %ld)", PSize*PSize);
            fatal( buffer );
            }
    }    
    return(r);
}

long long int readBestKnownValue(const char *instanceName) {  
    FILE *f = fopen("best_known/best_known.txt", "r");
    if (!f) return -1;
    
    char buffer[256];
    char name[128];
    long long int value;
        
    while (fgets(buffer, sizeof(buffer), f)) {
        if (sscanf(buffer, "%s %lld", name, &value) == 2) { // parse lines of the form "instance_name value"
            if (strstr(name, instanceName) != NULL) {  // match found 
                fclose(f);
                return value;
            }
        }
    }
    fclose(f);
    return -1;
}




